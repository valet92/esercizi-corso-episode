document.write('<div id="container">output scritto da Javascript</div>');

document.getElementById('titolo').innerHTML = 'Iniziamo la nostra pratica';

alert('Usa il pop up per dare dei messaggi');
window.alert('Sto studiando JS');