var petPreferito = 'criceto';
var PetPreferito = 'coniglio';
console.log(petPreferito);

var $pet = 'giraffa';
console.log($pet);
var _pet = 'leone';
console.log(_pet);
var _pet2 = 'pantera';
document.write('<div id="container">' + _pet2 + ' scritto da Javascript</div>');